<?php

namespace ZnBundle\Language\Yii2\Admin;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

    public $controllerNamespace = __NAMESPACE__ . '\Controllers';

}
