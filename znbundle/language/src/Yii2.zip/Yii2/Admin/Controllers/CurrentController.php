<?php

namespace ZnBundle\Language\Yii2\Admin\Controllers;

class CurrentController extends \ZnBundle\Language\Yii2\Web\Controllers\CurrentController
{

}
