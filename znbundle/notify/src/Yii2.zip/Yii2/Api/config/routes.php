<?php

//$version = API_VERSION_STRING;

return [
    "GET {$version}/notify-test" => "notify/test/index",
    "DELETE {$version}/notify-test" => "notify/test/delete",
];
