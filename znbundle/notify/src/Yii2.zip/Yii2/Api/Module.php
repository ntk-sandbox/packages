<?php

namespace ZnBundle\Notify\Yii2\Api;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

}
