<?php

namespace ZnBundle\Dashboard\Yii2\Web;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

    public $controllerNamespace = __NAMESPACE__ . '\Controllers';

}
