<?php

return [
    "{$version}" => "dashboard/doc/show",
    "" => "dashboard/doc/index",
];
