<?php

namespace ZnBundle\Dashboard\Yii2\Api;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{


}
