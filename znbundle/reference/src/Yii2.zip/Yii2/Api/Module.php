<?php

namespace ZnBundle\Reference\Yii2\Api;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
